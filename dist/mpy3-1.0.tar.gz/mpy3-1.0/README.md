# mpy3
Ultra-minimal cli mp3 player
